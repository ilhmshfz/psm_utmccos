import 'package:dio/dio.dart';
import 'package:utmccos/Model/Tools/JsonParse/product_parse.dart';

abstract class HomeDataSource {
  Future<List<ProductEntity>> getProducts();
  Future<List<ProductEntity>> getProductsWithKeyWord(
      {required String keyWord});
}

class HomeRemoteDataSource implements HomeDataSource {
  final Dio httpClient;

  HomeRemoteDataSource({required this.httpClient});
  @override
  Future<List<ProductEntity>> getProducts() async {
    final response = await httpClient.get(
        "https://utmccos1-default-rtdb.asia-southeast1.firebasedatabase.app/.json");
    final List<ProductEntity> productList = [];
    for (var product in (response.data) as List) {
      productList.add(ProductEntity.fromJson(product));
    }
    return productList;
  }

  @override
  Future<List<ProductEntity>> getProductsWithKeyWord(
      {required String keyWord}) async {
    final response = await httpClient.get(
        "https://eduewaqyyfkvrgiaxodz.supabase.co/rest/v1/product?apikey=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVkdWV3YXF5eWZrdnJnaWF4b2R6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3MTc2MzU3NjksImV4cCI6MjAzMzIxMTc2OX0.nVwIUsbozhI9pshcHLctYHHyixUdglexewS9cP7i_u4$keyWord");
    final List<ProductEntity> productList = [];
    final data=(response.data)as List;
    if (data.isNotEmpty) {
      for (var element in data) {
        productList.add(ProductEntity.fromJson(element));
      }
    }
    return productList;
  }
}

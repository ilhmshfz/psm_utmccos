part of 'favorite_bloc.dart';

@immutable
abstract class FavoriteEvent {}

class FavoriteStart extends FavoriteEvent{}